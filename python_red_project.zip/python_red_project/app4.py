import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import requests
import pandas as pd
import plotly.express as px

# API-ключ AccuWeather
# api_key = "Eqenp6euvkSxWLaIWTB7LbVkGmHAqae8"
api_key = "swZ6VHZnmuDrZjXkUnQMogG1bHwBJkuK"

def fetch_location_key(api_key, city_name):
    url = f"http://dataservice.accuweather.com/locations/v1/cities/search?apikey={api_key}&q={city_name}"
    response = requests.get(url)

    if response.status_code != 200:
        print(f"Ошибка при запросе локации: {response.status_code}")
        print(f"Ответ: {response.text}")
        return None

    try:
        locations = response.json()
        if locations:
            location_key = locations[0]['Key']
            print(f"Найден location_key: {location_key}")
            return location_key
        else:
            print("Локация не найдена.")
            return None
    except Exception as e:
        print(f"Ошибка при разборе JSON локации: {e}")
        return None


def fetch_weather_data(api_key, location_key, days=5):
    if days == 1:
        url = f"http://dataservice.accuweather.com/forecasts/v1/hourly/12hour/{location_key}?apikey={api_key}&details=true"
    else:
        url = f"http://dataservice.accuweather.com/forecasts/v1/daily/{days}day/{location_key}?apikey={api_key}&details=true"

    response = requests.get(url)

    if response.status_code != 200:
        print(f"Ошибка при запросе API: {response.status_code}")
        print(f"Ответ от сервера: {response.text}")
        return None

    try:
        data = response.json()
        return data
    except Exception as e:
        print(f"Ошибка при разборе JSON: {e}")
        return None


def process_weather_data(data, days):
    if not data:
        print("Ошибка: Данные отсутствуют.")
        return pd.DataFrame()

    if days == 1:
        weather_df = pd.DataFrame({
            'Date': [entry['DateTime'][:10] for entry in data],
            'Temperature': [entry['Temperature']['Value'] for entry in data],
            'Wind': [entry['Wind']['Speed']['Value'] for entry in data],
            'Precipitation': [entry.get('PrecipitationProbability', 0) for entry in data],
        })
    else:
        days_data = data['DailyForecasts']
        weather_df = pd.DataFrame({
            'Date': [day['Date'][:10] for day in days_data],
            'Temperature': [day['Temperature']['Maximum']['Value'] for day in days_data],
            'Wind': [day['Day']['Wind']['Speed']['Value'] for day in days_data],
            'Precipitation': [day['Day']['PrecipitationProbability'] for day in days_data],
        })
    return weather_df


app = dash.Dash(__name__)


route_cities = []


app.layout = html.Div([
    html.H1("Прогноз погоды для маршрута", style={'textAlign': 'center'}),


    html.Div([
        dcc.Input(id='city-input', type='text', placeholder='Введите город...', debounce=True),
        html.Button('Добавить точку', id='add-city', n_clicks=0),
        html.Button('Очистить маршрут', id='clear-route', n_clicks=0),
        html.Div(id='city-list', children=[]),
    ]),


    html.Div([
        html.Label('Выберите параметр для отображения:'),
        dcc.RadioItems(
            id='parameter-selector',
            options=[
                {'label': 'Температура', 'value': 'Temperature'},
                {'label': 'Осадки', 'value': 'Precipitation'},
                {'label': 'Сила ветра', 'value': 'Wind'},
            ],
            value='Temperature',
            inline=True
        )
    ], style={'marginTop': '20px'}),


    html.Div([
        html.Label('Выберите временной интервал:'),
        dcc.RadioItems(
            id='time-interval',
            options=[
                {'label': '1 день', 'value': 1},
                {'label': '3 дня', 'value': 3},
                {'label': '5 дней', 'value': 5},
            ],
            value=5,
            inline=True
        )
    ], style={'marginTop': '20px'}),


    dcc.Graph(id='route-weather-graph'),
    dcc.Graph(id='route-map')
])

@app.callback(
    [Output('city-list', 'children'),
     Output('route-weather-graph', 'figure'),
     Output('route-map', 'figure')],
    [Input('add-city', 'n_clicks'),
     Input('clear-route', 'n_clicks')],
    [State('city-input', 'value'),
     State('time-interval', 'value'),
     State('parameter-selector', 'value')]
)
def update_route(add_clicks, clear_clicks, city_name, time_interval, parameter):
    global route_cities


    if clear_clicks > 0:
        route_cities = []
        return [html.Ul([]), {}, {}]


    if city_name and city_name not in route_cities:
        route_cities.append(city_name)


    all_weather_data = []
    route_coords = []
    for city in route_cities:
        location_key = fetch_location_key(api_key, city)
        if location_key:
            weather_data = fetch_weather_data(api_key, location_key, days=time_interval)
            if weather_data:
                weather_df = process_weather_data(weather_data, time_interval)
                weather_df['City'] = city
                all_weather_data.append(weather_df)


                location_url = f"http://dataservice.accuweather.com/locations/v1/cities/search?apikey={api_key}&q={city}"
                response = requests.get(location_url).json()
                lat, lon = response[0]['GeoPosition']['Latitude'], response[0]['GeoPosition']['Longitude']
                route_coords.append({'City': city, 'Latitude': lat, 'Longitude': lon})

    if not all_weather_data:
        return [html.Ul([html.Li(city) for city in route_cities]), {}, {}]

    combined_data = pd.concat(all_weather_data)


    weather_fig = px.line(combined_data, x='Date', y=parameter, color='City', title=f"{parameter} по маршруту")
    weather_fig.update_layout(hovermode="x unified", legend_title_text='Города', xaxis_title='Дата',
                              yaxis_title=parameter)


    route_df = pd.DataFrame(route_coords)
    map_fig = px.scatter_mapbox(
        route_df,
        lat='Latitude',
        lon='Longitude',
        text='City',
        title="Маршрут с погодными данными",
        mapbox_style="open-street-map",
        hover_name='City',
        zoom=4,
        size_max=15
    )

    return [html.Ul([html.Li(city) for city in route_cities]), weather_fig, map_fig]


if __name__ == '__main__':
    app.run_server(debug=False, port=8051)